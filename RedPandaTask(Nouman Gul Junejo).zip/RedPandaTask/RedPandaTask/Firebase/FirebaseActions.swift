//
//  FirebaseActions.swift
//  RedPandaTask
//
//  Created by Nouman Gul on 31/10/2022.
//

import Foundation

enum FirebaseActions:String{
    case create
    case update
    case delete
}
