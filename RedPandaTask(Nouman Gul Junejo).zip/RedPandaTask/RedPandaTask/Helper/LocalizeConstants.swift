//
//  Constants.swift
//  RedPandaTask
//
//  Created by Nouman Gul on 29/10/2022.
//

import Foundation

struct LocalizeConstants{ 
    let currencySymbol = "Rs"
    let productTitle = "Product"
}
