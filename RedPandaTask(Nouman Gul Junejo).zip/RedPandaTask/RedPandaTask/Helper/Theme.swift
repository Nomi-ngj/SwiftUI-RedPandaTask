//
//  Theme.swift
//  RedPandaTask
//
//  Created by Nouman Gul on 31/10/2022.
//

import Foundation

struct Theme{
    static let networkContants = NetworkContants()
    static let constants = LocalizeConstants()
}
