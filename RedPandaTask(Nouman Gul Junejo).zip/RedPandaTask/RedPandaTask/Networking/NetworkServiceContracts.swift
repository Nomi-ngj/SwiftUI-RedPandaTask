//
//  NetworkServiceContracts.swift
//  RedPandaTask
//
//  Created by Nouman Gul on 29/10/2022.
//

import Foundation

protocol NetworkConsumable{
    var url:URL {get set}
}
