//
//  NetworkContants.swift
//  RedPandaTask
//
//  Created by Nouman Gul on 29/10/2022.
//

import Foundation

struct NetworkContants{
    let serverUrl:URL = URL(string:"http://35.154.26.203/product-ids")!
}
